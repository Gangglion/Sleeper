package com.example.sleep_project;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class UI_2_Maintimertabqna extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ui_2_maintimertabqna);
    }
}
