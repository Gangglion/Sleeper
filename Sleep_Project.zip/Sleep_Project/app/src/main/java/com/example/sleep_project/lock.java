package com.example.sleep_project;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class lock extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lock);

    }
}
