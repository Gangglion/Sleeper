﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Toolkit.Uwp.Notifications;
using MySql.Data.MySqlClient;

namespace Sleeper_Form
{
    public partial class Form1 : Form
    {
        //취침할 시간 값, ToDateTime 괄호 안에 시간 입력값 불러오면 될 듯?
        static DateTime SleepDate = Convert.ToDateTime("23시 00분");
        
        //일어날 시간 값, 얘도 마찬가지로
        static DateTime AwakeDate = Convert.ToDateTime("01시 00분");
        
        //취침까지 남은 시간 값, 밑에 타이머 4 설정에 취침할 시간 - 일어날 시간 값으로 지정 되어 있음.
        TimeSpan dateDiff = AwakeDate.Subtract(SleepDate);
        DateTime DT1;

        public Form1()
        {
            
            InitializeComponent();

            //현재시간 설정
            timer1.Interval = 1000;
            timer1.Enabled = true;
            timer1.Tick += timer1_Tick;

            // this는 Form1을 가리킴 배경색
            // this.BackColor = Color.LightSteelBlue;
            // this.Text = "myDigitalClock";

            //현재 시간 나타나는 곳
            ThisTimeLabel.Text = DateTime.Now.ToString();
            
            //예약한 시간 설정
            timer2.Interval = 1000;
            timer2.Enabled = true;

            //수면까지 남은 시간 설정
            timer3.Interval = 1000;
            timer3.Enabled = true;

            //취침까지 남은 시간 설정
            timer4.Interval = 1000;
            timer4.Enabled = true;


            //우측 하단 알림창 뜨게 해주는 코드인데 수정 해야함
            new ToastContentBuilder()
                .AddArgument("conversationId", 9813)
                .AddText("취침 시간까지" + dateDiff + "남았습니다")
                .Show();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //현재 시간 나타나는 곳 Now라서 년도부터 초까지 나타남
            ThisTimeLabel.Text = DateTime.Now.ToString();

        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            //취침할 시간 나타나는 곳 오전, 오후 시간 : 분
            SleepTLabel.Text = SleepDate.ToString("tt HH:mm");
            
            
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            //일어날 시간 나타나는 곳 오전, 오후 시간 : 분
            AwakeTLabel.Text = AwakeDate.ToString("tt HH:mm");
            
        }

        private void timer4_Tick(object sender, EventArgs e)
        {
            //취침까지 남은 시간 나타나는 곳 시간 : 분 : 초
            
            TimeSpan dateDiff = SleepDate - AwakeDate;
            LeftSleepTLabel.Text = DT1.Subtract(dateDiff).ToString("HH시 mm분");
            String temp = SleepDate.ToString();
            String TempHour = temp.Substring(0, 1);
            String TempMin = temp.Substring(3,4);
            String temp2 = AwakeDate.ToString();
            String TempHour2 = temp2.Substring(0, 1);
            String TempMin2 = temp2.Substring(3, 4);
            String temp3 = dateDiff.ToString();
            String TempHour3 = temp3.Substring(0, 1);
            String TempMin3 = temp3.Substring(4, 5);

            int TemH = Convert.ToInt32(TempHour);
            int TemM = Convert.ToInt32(TempMin);
            int TemH2 = Convert.ToInt32(TempHour2);
            int TemM2 = Convert.ToInt32(TempMin2);
            int TemH3 = Convert.ToInt32(TempHour3);
            int TemM3 = Convert.ToInt32(TempMin3);

            if (TemH > TemH2 && TemH < 12 && TemH2 > 12)
            {
                TemH2 += 24;
            }
            if(TemH2 < TemH)
            {
                TemM2 += 60;
                TemH2 -= 1;
            }
            TemH3 = TemH - TemH2;
            TemM3 = TemM - TemM2;
            //if(==00+"시간"+30+"분")
            //{
//
  //          }

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MariaUtil mariaUtil = new MariaUtil();
        }
    }
    class MariaUtil
    {
        private MySqlConnection dbConnection;
        

        //open
        public int open()
        {
            if (isOpen())
            {
               // close();
            }

            int iret = 0;

            //각 서버의 설정에 맞게 수정
            String connectionString = "Server=glion.ddns.net;Port=3306;Database=Sleeper;Uid=glion;Pwd=setterGetter4s^g;Charset=utf8";
            dbConnection = new MySqlConnection(connectionString);
            try
            {
                iret = 1;
                dbConnection.Open();
                Console.Write("마리아DB 오픈완료");
            }
            catch (Exception e)
            {
                Console.Write("DB 오픈 : " + e.Message.ToString());
                close();
                iret = -1;

            }
            return iret;

        }

        //open여부
        public Boolean isOpen()
        {
            if (dbConnection != null) return true;
            else return false;
        }
        public MariaUtil()
        {
           if (open() == 1)
            {
                MessageBox.Show(this.ToString(), "오픈 성공");
            }
            else
            {
                MessageBox.Show(this.ToString(), "오픈 실패");
            }
        }
        //close
        public int close()
        {
            int iret = 1;
            try
            {
                if (dbConnection != null)
                {
                    dbConnection.Close();
                    Console.WriteLine("DB 클로즈");
                }
            }
            catch (Exception e)
            {
                iret = -1;
            }
            dbConnection = null;
            return iret;
        }

        //insert, update, delete => 성공한 row개수 리턴(1: 성공)
        public int run(String sql)
        {
            int iret = 0;
            try
            {
                Console.WriteLine("Maria DB 연결 중...");
                //connection.Open();
                MySqlCommand mySqlCommand = new MySqlCommand(sql, dbConnection);
                iret = mySqlCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            return iret;
        }

        //insert, update, delete transaction => 성공한 row개수 리턴(1이상: 성공)
        public int runs(String[] sqls)
        {
            int iret = 0;

            MySqlCommand cmd = dbConnection.CreateCommand();
            MySqlTransaction tran = dbConnection.BeginTransaction();

            cmd.Connection = dbConnection;
            cmd.Transaction = tran;
            if (dbConnection == null || tran == null) iret = -2;
            else
            {
                try
                {
                    for (int i = 0; i < sqls.Length; i++)
                    {
                        cmd.CommandText = sqls[i];
                        iret += cmd.ExecuteNonQuery();//정상이면 1 리턴
                    }
                    tran.Commit();
                    Console.WriteLine("마리아DB 커밋 완료 :");
                }
                catch (Exception e)
                {
                    Console.WriteLine("DB 트랜잭션 : " + e.Message.ToString());
                    tran.Rollback();
                    iret = -1;
                }
            }

            return iret;
        }

        //select 쿼리 수행 -> DataTable 리턴
        public DataTable select(String sql)
        {
            var mySqlDataTable = new DataTable();
            try
            {
                MySqlCommand mySqlCommand = new MySqlCommand(sql, dbConnection);
                MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
                mySqlDataTable.Load(mySqlDataReader);

                StringBuilder output = new StringBuilder();
                foreach (DataColumn col in mySqlDataTable.Columns)
                {
                    output.AppendFormat("{0} ", col);
                }
                output.AppendLine();
                foreach (DataRow page in mySqlDataTable.Rows)
                {
                    foreach (DataColumn col in mySqlDataTable.Columns)
                    {
                        output.AppendFormat("{0} ", page[col]);
                    }
                    output.AppendLine();

                }
                Console.WriteLine(output.ToString());

                mySqlDataReader.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            return mySqlDataTable;
        }

    }
}
