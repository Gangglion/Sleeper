﻿
namespace Sleeper_Form
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.ThisTimeLabel = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label4 = new System.Windows.Forms.Label();
            this.SleepTLabel = new System.Windows.Forms.Label();
            this.AwakeTLabel = new System.Windows.Forms.Label();
            this.LeftSleepTLabel = new System.Windows.Forms.Label();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.timer4 = new System.Windows.Forms.Timer(this.components);
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(17, 102);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 21);
            this.label1.TabIndex = 0;
            this.label1.Text = "취침할 시간";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.Location = new System.Drawing.Point(84, 179);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(150, 21);
            this.label2.TabIndex = 1;
            this.label2.Text = "취침까지 남은 시간";
            // 
            // ThisTimeLabel
            // 
            this.ThisTimeLabel.Font = new System.Drawing.Font("맑은 고딕 Semilight", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ThisTimeLabel.Location = new System.Drawing.Point(18, 38);
            this.ThisTimeLabel.Name = "ThisTimeLabel";
            this.ThisTimeLabel.Size = new System.Drawing.Size(312, 42);
            this.ThisTimeLabel.TabIndex = 2;
            this.ThisTimeLabel.Text = "현재시간";
            this.ThisTimeLabel.Click += new System.EventHandler(this.label3_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label4.Location = new System.Drawing.Point(180, 102);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(96, 21);
            this.label4.TabIndex = 3;
            this.label4.Text = "일어날 시간";
            // 
            // SleepTLabel
            // 
            this.SleepTLabel.AutoSize = true;
            this.SleepTLabel.Location = new System.Drawing.Point(21, 141);
            this.SleepTLabel.Name = "SleepTLabel";
            this.SleepTLabel.Size = new System.Drawing.Size(49, 12);
            this.SleepTLabel.TabIndex = 4;
            this.SleepTLabel.Text = "00:00:00";
            this.SleepTLabel.Click += new System.EventHandler(this.label5_Click);
            // 
            // AwakeTLabel
            // 
            this.AwakeTLabel.AutoSize = true;
            this.AwakeTLabel.Location = new System.Drawing.Point(182, 141);
            this.AwakeTLabel.Name = "AwakeTLabel";
            this.AwakeTLabel.Size = new System.Drawing.Size(49, 12);
            this.AwakeTLabel.TabIndex = 5;
            this.AwakeTLabel.Text = "00:00:00";
            // 
            // LeftSleepTLabel
            // 
            this.LeftSleepTLabel.AutoSize = true;
            this.LeftSleepTLabel.Location = new System.Drawing.Point(132, 223);
            this.LeftSleepTLabel.Name = "LeftSleepTLabel";
            this.LeftSleepTLabel.Size = new System.Drawing.Size(49, 12);
            this.LeftSleepTLabel.TabIndex = 6;
            this.LeftSleepTLabel.Text = "00:00:00";
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // timer3
            // 
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // timer4
            // 
            this.timer4.Tick += new System.EventHandler(this.timer4_Tick);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(302, 239);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(40, 19);
            this.button1.TabIndex = 7;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(367, 270);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.LeftSleepTLabel);
            this.Controls.Add(this.AwakeTLabel);
            this.Controls.Add(this.SleepTLabel);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.ThisTimeLabel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Sleeper";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label ThisTimeLabel;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label SleepTLabel;
        private System.Windows.Forms.Label AwakeTLabel;
        private System.Windows.Forms.Label LeftSleepTLabel;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.Timer timer4;
        private System.Windows.Forms.Button button1;
    }
}

